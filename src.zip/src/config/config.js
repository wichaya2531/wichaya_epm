

export const config = {
   /**********PRB****************/      
    // "host_link": "http://prbepm.wdc.com:3000"  ,
    // "host": "http://prbepm.wdc.com:3000"
    /**********LOCAL****************/  
    //  "host_link": "http://localhost:3000"  ,
    //  "host": "http://localhost:3000"    
   /**********BPI****************/  
   // "host_link": /*"http://10.171.134.51:3000" */ ,
   // "host":   /*"http://10.171.134.51:3000"*/
      /**********FJ****************/  
    // "host_link": "http://10.148.138.185:3000"  ,
    // "host": "http://10.148.138.185:3000"
}     