import { Job } from "@/lib/models/Job";
import { JobItem } from "@/lib/models/JobItem";
import { NextResponse } from "next/server";
import { User } from "@/lib/models/User";
import { Status } from "@/lib/models/Status";
import { connectToDb } from "@/app/api/mongo/index.js";
import { Schedule } from "@/lib/models/Schedule.js";
import { JobTemplate } from "@/lib/models/JobTemplate";
export const dynamic = "force-dynamic";
export const POST = async (req) => {
    await connectToDb();

    try {
        const body = await req.json();
        const { workgroup_id, checklistname, status, startDate, endDate } = body;

        console.log();
        if (!workgroup_id || workgroup_id === "undefined") {
            return NextResponse.json({
                status: 400,
                error: "Workgroup ID is required",
            });
        }

        const status_id = await Status.findOne({ status_name: status });
        let jobFilter = { WORKGROUP_ID: workgroup_id };
        if (checklistname) jobFilter.JOB_NAME = { $regex: checklistname, $options: "i" };
        if (status) jobFilter.JOB_STATUS_ID = status_id?._id;
        if (startDate || endDate) {
            jobFilter.createdAt = {};
            if (startDate) jobFilter.createdAt.$gte = new Date(startDate);
            if (endDate) jobFilter.createdAt.$lte = new Date(endDate);
        }
        // console.log("status_id:", status_id);
        console.log("jobFilter:", jobFilter);
        // Build filter object for Job

        // Build filter object for Schedule
        let scheduleFilter = { WORKGROUP_ID: workgroup_id };
        if (checklistname) scheduleFilter.JOB_TEMPLATE_NAME = { $regex: checklistname, $options: "i" };
        if (status) scheduleFilter.STATUS = status_id?._id;
        if (startDate || endDate) {
            scheduleFilter.ACTIVATE_DATE = {};
            if (startDate) scheduleFilter.ACTIVATE_DATE.$gte = new Date(startDate);
            if (endDate) scheduleFilter.ACTIVATE_DATE.$lte = new Date(endDate);
        }


        // Fetch all jobs and schedules (no streaming)
        const jobs = await Job.find(jobFilter).sort({ createdAt: -1 });
        const schedules = await Schedule.find(scheduleFilter).sort({ createdAt: -1 });

       // console.log("jobs:", jobs.length);
       // console.log("schedules:", schedules.length);

      //  return NextResponse.json({ result: true });

        const jobPromises = jobs.map(async (job) => {
            const user = await User.findOne({ _id: job.ACTIVATE_USER });
            const statusObj = await Status.findOne({ _id: job.JOB_STATUS_ID });
            const activaterName = user?.EMP_NAME || "Unknown";
            const statusName = statusObj?.status_name || "Unknown";
            const statusColor = statusObj?.color || "Unknown";

            return {
                SUBMITTED_BY: { EMP_NAME: "Jack" },
                LINE_NAME: job.LINE_NAME,
                JOB_NAME: job.JOB_NAME,
                ACTIVATE_USER: job.ACTIVATE_USER,
                createdAt: job.createdAt,
                ACTIVATER_NAME: activaterName,
                STATUS_NAME: statusName,
                STATUS_COLOR: statusColor,
                ITEM_ABNORMAL: job.VALUE_ITEM_ABNORMAL || false,
                VALUE_ITEM_ABNORMAL: job.VALUE_ITEM_ABNORMAL,
            };
        });

        const schedulePromises = schedules.map(async (schedule) => {
            const statusObj = await Status.findOne({ status_name: schedule.STATUS });
            const statusColor = statusObj?.color || "Unknown";
            return {
                _id: schedule._id,
                LINE_NAME: schedule.LINE_NAME,
                JOB_NAME: schedule.JOB_TEMPLATE_NAME,
                ACTIVATE_USER: "Scheduler",
                createdAt: new Date(schedule.ACTIVATE_DATE).toISOString(),
                ACTIVATER_NAME: "Scheduler",
                STATUS_NAME: schedule.STATUS,
                STATUS_COLOR: statusColor,
            };
        });

        const combinedPromises = [...jobPromises, ...schedulePromises];
        let jobsWithActivater = await Promise.all(combinedPromises);

        jobsWithActivater.sort((a, b) => {
            return new Date(b.createdAt) - new Date(a.createdAt);
        });
        
        console.log("Total combined jobs and schedules:", jobsWithActivater.length);
        return NextResponse.json(jobsWithActivater);
    } catch (err) {
        console.log("Error", err);
        return NextResponse.json({ status: 500, error: err.message });
    }
};
