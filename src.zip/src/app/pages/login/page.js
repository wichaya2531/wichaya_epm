import LoginForm from "./LoginForm";

const Home = () => {
      // return(
      //   <div style={{padding:'20px',fontSize:'2em'}}>
      //         <br></br>
      //           <a>"ขณะนี้ระบบอยู่ระหว่างการบำรุงรักษา คาดว่าจะกลับมาใช้งานได้ตามปกติภายใน 1 ชั่วโมง ขออภัยในความไม่สะดวก "</a>
      //           <a>"The system is currently undergoing maintenance. We expect to resume normal operation within 1 hour."</a>        
      //   </div>
      // )
      return <LoginForm />;
};

export default Home;
