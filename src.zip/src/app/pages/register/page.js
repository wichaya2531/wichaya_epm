import RegisterForm from "./RegisterForm";


const Page = () => {
    return (
        <div className="w-screen h-screen flex justify-center items-center">
            <RegisterForm/>
        </div>
    );
}

export default Page;