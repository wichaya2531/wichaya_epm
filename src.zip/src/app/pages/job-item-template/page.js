"use client";
import Layout from "@/components/Layout.js";
import TableComponent from "@/components/TableComponent.js";
import { getSession } from "@/lib/utils/utils";
import { useEffect, useState } from "react";
import { config } from "@/config/config.js";
import Link from "next/link";
import Swal from "sweetalert2";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import Image from "next/image"; 
import { useRouter } from "next/navigation";

const jobItemTemplateHeader = [
  "ID",
  "LINE NAME",
  "Checklist Template Name",
  "Document no.",
  "Version.",
  "Created At",
  "Action",
];

const enabledFunction = {
  "edit-job-template": "663313bbeccb576a719dfa9c",
  "remove-job-template": "663313b1eccb576a719dfa9a",
  "add-job-item-template": "6638600dd81a314967236df5",
};

const Page = () => {
   const router = useRouter();
  const [refresh, setRefresh] = useState(false);
  const [jobTemplates, setJobTemplates] = useState([]);
  const [session, setSession] = useState({});
  const [user, setUser] = useState({});
  const [userEnableFunctions, setUserEnableFunctions] = useState([]);
  const [selectedLineName, setSelectedLineName] = useState("");
  const [selectedTemplateName, setSelectedTemplateName] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    retrieveSession();
  }, [refresh]);

  const retrieveSession = async () => {
    const session = await getSession();
    setSession(session);
    await fetchUser(session.user_id);
  };

  const fetchUser = async (user_id) => {
    try {
      const response = await fetch(`/api/user/get-user/${user_id}`, {
        next: { revalidate: 10 },
      });
      if (!response.ok) {
        throw new Error("Failed to fetch user data");
      }
      const data = await response.json();
      setUser(data.user);
      setUserEnableFunctions(data.user.actions);
      await fetchJobTemplates(data.user.workgroup_id);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchJobTemplates = async (workgroup_id) => {
    try {
      const response = await fetch(
        `/api/workgroup/get-job-templates-from-workgroup/${workgroup_id}`,
        { next: { revalidate: 10 } }
      );
      const data = await response.json();
      //console.log(data);
      if (data.status === 200) {
        setJobTemplates(data.jobTemplates);
      }
    } catch (err) {
      console.log("err", err);
    }
  };

  const handleRemove = async (jobTemplate_id, JobTemplateCreateID) => {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: true,
    });

    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, cancel!",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          try {
            const response = await fetch(
              "/api/job-template/remove-job-template",
              {
                method: "DELETE",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({ jobTemplate_id, JobTemplateCreateID }),
                next: { revalidate: 10 },
              }
            );
            const data = await response.json();
            if (data.status === 200) {
              swalWithBootstrapButtons.fire({
                title: "Deleted!",
                text: "The Checklist template has been deleted.",
                icon: "success",
              });
              setRefresh((prev) => !prev);
            }
          } catch (err) {
            console.error("Error deleting Checklist template:", err);
          }
        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === Swal.DismissReason.cancel
        ) {
          swalWithBootstrapButtons.fire({
            title: "Cancelled",
            text: "The deletion action was cancelled.",
            icon: "error",
          });
        }
      });
  };


  const handleInfoPlus=async (job_template_id, LINE_NAME) => {
    Swal.fire({
      title: "API Url",
      html: `
              <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                  <div style="width:100%;text-align:left;">
                      <div style="border:1px solid none;width:100%;padding:5px;" >
                        <p style="margin: 0;font-size:14px;"> Create :------------------- 
                         <button id="copy-btn-create" class="swal2-confirm swal2-styled" 
                            style="background-color: #3085d6; color: white; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;">
                            Copy 
                         </button>
                        </p>
                      </div>
                      <div style="border:1px solid none;width:100%;padding:5px;">
                        <p style="margin: 0;font-size:14px;"> Query :-------------------
                            <button id="copy-btn-view" class="swal2-confirm swal2-styled" 
                              style="background-color: #3085d6; color: white; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;">
                              Copy 
                            </button>
                        </p>
                      </div>
                  </div>    
                  <p></p>
                 
              </div>
          `,
      showConfirmButton: false, // ซ่อนปุ่ม "OK" เริ่มต้น
      width: "auto",
    });
    // เพิ่ม Event Listener ให้กับปุ่ม Copy

    document.addEventListener("click", (event) => {
      if (event.target.id === "copy-btn-create") {
        const textArea = document.createElement("textarea");
        textArea.value = `${process.env.NEXT_PUBLIC_HOST_LINK}/api/job/activate-job-template-third-party/?job_key=${job_template_id}&line=${LINE_NAME}&user_id=${session.user_id}`; //job_template_id`;
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand("copy");
          Swal.fire("Copied!", "ID has been copied to clipboard.", "success");
        } catch (err) {
          Swal.fire("Oops!", "Failed to copy ID.", "error");
        }
        document.body.removeChild(textArea);
      }
    });
  }
  
  const handleInfo = async (job_template_id, LINE_NAME) => {
    Swal.fire({
      title: "API Url",
      html: `
              <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                  <div style="width:100%;text-align:left;">
                      <div style="border:1px solid none;width:100%;padding:5px;" >
                        <p style="margin: 0;font-size:14px;"> Create :<a href='#'>${process.env.NEXT_PUBLIC_HOST_LINK}/api/job/activate-job-template-third-party/?job_key=${job_template_id}&line=${LINE_NAME}&user_id=${session.user_id} </a>
                         <button id="copy-btn-create" class="swal2-confirm swal2-styled" 
                            style="background-color: #3085d6; color: white; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;">
                            Copy 
                         </button>
                        </p>
                      </div>
                      <div style="border:1px solid none;width:100%;padding:5px;">
                        <p style="margin: 0;font-size:14px;"> Query :<a href='#'></a>
                            <button id="copy-btn-view" class="swal2-confirm swal2-styled" 
                              style="background-color: #3085d6; color: white; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;">
                              Copy 
                            </button>
                        </p>
                      </div>
                  </div>    
                  <p></p>
                 
              </div>
          `,
      showConfirmButton: false, // ซ่อนปุ่ม "OK" เริ่มต้น
      width: "auto",
    });
    // เพิ่ม Event Listener ให้กับปุ่ม Copy

    document.addEventListener("click", (event) => {
      if (event.target.id === "copy-btn-create") {
        const textArea = document.createElement("textarea");
        textArea.value = `${process.env.NEXT_PUBLIC_HOST_LINK}/api/job/activate-job-template-third-party/?job_key=${job_template_id}&line=${LINE_NAME}&user_id=${session.user_id}`; //job_template_id`;
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand("copy");
          Swal.fire("Copied!", "ID has been copied to clipboard.", "success");
        } catch (err) {
          Swal.fire("Oops!", "Failed to copy ID.", "error");
        }
        document.body.removeChild(textArea);
      }
    });
  };


  
  const fetchWorkgroups = async () => {
    try {
      const response = await fetch(`/api/workgroup/get-workgroups`, {
        next: { revalidate: 10 },
      });
      if (!response.ok) {
        throw new Error("Failed to fetch roles");
      }
      const data = await response.json();
      return data;  
      //console.log('data all workgroups',data);
         
      //setWorkgroups(data.workgroups);
    } catch (error) {
      console.error(error);
    }
  };


  const handleCopyToWorkgroup = async (job_template_id) => {
    let allWorkgroup= await fetchWorkgroups();
    const workgroups=allWorkgroup.workgroups;
    //console.log('allWorkgroup',allWorkgroup.workgroups);

          const selectOptions = workgroups.map(wg => 
            `<option value="${wg._id}">${wg.WORKGROUP_NAME}</option>`
          ).join('');
        
            // เรียก Swal
            Swal.fire({
                title: 'Select Workgroup',
                html:
                    `<select id="swal-workgroup" class="swal2-input">
                        <option value="" disabled selected>Select a workgroup</option>
                        ${selectOptions}
                    </select>`,
                showCancelButton: true,
                confirmButtonText: 'OK',
                showCloseButton: true,  // << เพิ่มปุ่ม Close (X) ตรงนี้
                cancelButtonText: 'Cancel',
                preConfirm: () => {
                    const selectedValue = document.getElementById('swal-workgroup').value;
                    if (!selectedValue) {
                        Swal.showValidationMessage('Please select a workgroup');
                        return false;  // << เพิ่มบรรทัดนี้ เพื่อไม่ให้ Swal ปิด
                    }
                    return selectedValue;
                }
            }).then(async (result) => {
                if (result.isConfirmed) {
                    console.log('Selected Workgroup ID:', result.value);
                    // ทำงานต่อได้เลย เช่น ส่งค่าไปใช้ต่อ
                    const res = await fetch(
                      `/api/job-template/copy-job-template?job_template_id=${job_template_id}&workgroup_id=${result.value}`
                    );
                    //console.log(res);
                    if (res.ok) {
                      const result = await res.json();
                      //console.log(result.message); // แสดงข้อความตอบกลับจากเซิร์ฟเวอร์
                      setRefresh((prev) => !prev);
                        // ✅ แจ้ง Swal เมื่อสำเร็จ
                        Swal.fire({
                          icon: 'success',
                          title: 'Copy Success',
                          text: 'The job template was copied successfully.'
                        });
                    } else {
                      console.error("Error:", res.statusText);
                      // ❌ แจ้ง Swal เมื่อ Error
                      Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to copy the job template.'
                      });

                    }

                } else {
                    console.log('Cancelled');
                }
            });
  }


  

  const handleCopy = async (job_template_id) => {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger",
      },
      buttonsStyling: true,
    });

    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "Are you sure to copy this Template!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, Copy it!",
        cancelButtonText: "No, cancel!",
        reverseButtons: true,
      })
      .then(async (result) => {
        if (result.isConfirmed) {
          const data = {
            job_template_id: job_template_id,
          };

          const res = await fetch(
            `/api/job-template/copy-job-template?job_template_id=${job_template_id}`
          );
          //console.log(res);
          if (res.ok) {
            const result = await res.json();
            //console.log(result.message); // แสดงข้อความตอบกลับจากเซิร์ฟเวอร์
            setRefresh((prev) => !prev);
          } else {
            console.error("Error:", res.statusText);
          }
        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === Swal.DismissReason.cancel
        ) {
          swalWithBootstrapButtons.fire({
            title: "Cancelled",
            text: "The Copy action was cancelled.",
            icon: "error",
          });
        }
      });
  };

  // หา LINE NAME ที่ไม่ซ้ำกันเพื่อสร้างตัวเลือกในฟิลเตอร์
  const uniqueLineNames = [
    ...new Set(
      jobTemplates.map((jobTemplate) => jobTemplate.LINE_NAME || "N/A")
    ),
  ];

  // หา CHECKLIST TEMPLATE NAME ที่ไม่ซ้ำกันเพื่อสร้างตัวเลือกในฟิลเตอร์
  const uniqueTemplateNames = [
    ...new Set(
      jobTemplates.map((jobTemplate) => jobTemplate.JOB_TEMPLATE_NAME || "N/A")
    ),
  ];

  // ฟังก์ชันการกรองตาม LINE NAME และ CHECKLIST TEMPLATE NAME ที่เลือก
  const filteredJobTemplates = jobTemplates.filter((jobTemplate) => {
    const matchesLineName = selectedLineName
      ? jobTemplate.LINE_NAME === selectedLineName
      : true;
    const matchesTemplateName = selectedTemplateName
      ? jobTemplate.JOB_TEMPLATE_NAME === selectedTemplateName
      : true;
    return matchesLineName && matchesTemplateName;
  });

  const jobItemTemplateBody = filteredJobTemplates.map((jobTemplate, index) => {
    return {
      ID: index + 1,
      "LINE NAME": jobTemplate.LINE_NAME || "N/A",
      "Checklist Template Name": jobTemplate.JOB_TEMPLATE_NAME,
      "Document no.": jobTemplate.DOC_NUMBER,
      "Version.":jobTemplate.CHECKLIST_VERSION,
      "Create At": jobTemplate.createdAt,
      Action: (
        <div className="flex gap-2 items-center justify-center">
          <Link
            className="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded"
            href={{
              pathname: "/pages/edit-job-template",
              query: { jobTemplate_id: jobTemplate._id },
            }}
            disabled={
              !userEnableFunctions.some(
                (action) => action._id === enabledFunction["edit-job-template"]
              )
            }
            style={{
              cursor: !userEnableFunctions.some(
                (action) => action._id === enabledFunction["edit-job-template"]
              )
                ? "not-allowed"
                : "pointer",
            }}
          >
            Edit
          </Link>
          <button
            onClick={() => handleCopy(jobTemplate._id)}
            className="bg-slate-500 hover:bg-slate-700 text-white font-semibold py-2 px-2 rounded"
          >
            Duplicate
          </button>

          <button
            onClick={() => handleCopyToWorkgroup(jobTemplate._id)}
            className="bg-slate-500 hover:bg-slate-700 text-white font-semibold text-xs py-2 px-2 rounded"
          >
            Copy to workgroup.
          </button>

          <button
            className="bg-red-500 hover:bg-red-700 text-white font-semibold py-2 px-2 rounded"
            onClick={() =>
              handleRemove(jobTemplate._id, jobTemplate.JobTemplateCreateID)
            }
            disabled={
              !userEnableFunctions.some(
                (action) =>
                  action._id === enabledFunction["remove-job-template"]
              )
            }
            style={{
              cursor: !userEnableFunctions.some(
                (action) =>
                  action._id === enabledFunction["remove-job-template"]
              )
                ? "not-allowed"
                : "pointer",
            }}
          >
            Remove
          </button>
          <Link
            className="bg-teal-500 hover:bg-teal-700 text-white font-semibold text-xs py-2 px-2 rounded"
            href={{
              pathname: "/pages/job-item-template/add-job-item-template",
              query: { jobTemplate_id: jobTemplate._id },
            }}
            disabled={
              !userEnableFunctions.some(
                (action) =>
                  action._id === enabledFunction["add-job-item-template"]
              )
            }
            style={{
              cursor: !userEnableFunctions.some(
                (action) =>
                  action._id === enabledFunction["add-job-item-template"]
              )
                ? "not-allowed"
                : "pointer",
            }}
          >
            Add/Edit Item
          </Link>

          <button
            onClick={() => handleInfo(jobTemplate._id, jobTemplate.LINE_NAME)}
            className="bg-slate-500 hover:bg-slate-700 text-white font-semibold py-2 px-2 rounded"
          >
            API
          </button>

          <button
            onClick={() => handleInfoPlus(jobTemplate._id, jobTemplate.LINE_NAME)}
            className="bg-slate-500 hover:bg-slate-700 text-white font-semibold py-2 px-2 rounded"
          >
            API+
          </button>

        </div>
      ),
    };
  });





  return (
    <Layout className="container flex flex-col left-0 right-0 mx-auto justify-start font-sans mt-2 px-6 gap-5">
      <div className="flex flex-col items-start gap-4 mb-4 p-4 bg-white rounded-xl">
        <h1 className="text-3xl font-bold text-primary flex  items-center ">
          <Link href="/pages/dashboard">
            <ArrowBackIosNewIcon />
          </Link>
          <Image
            src="/assets/card-logo/management.png"
            alt="wd logo"
            width={50}
            height={50}
          />
          WorkGroup: {user.workgroup}{" "}
        </h1>
        <h1 className="text-2xl font-bold">Checklist Templates</h1>{" "}
      </div>

      <div className="flex flex-col gap-4 mb-4 p-4 bg-white rounded-xl">
        <div className="flex flex-col">
          {/* <label
            htmlFor="template-name-filter"
            className="text-lg font-bold mb-2"
          >
            Checklist Template Name:
          </label> */}
        <div style={{ border: '1px solid none' }} className="flex justify-between items-center p-2">
          <select
            id="template-name-filter"
            className="w-64 ml-0 border border-gray-300 p-2 rounded"
            value={selectedTemplateName}
            onChange={(e) => setSelectedTemplateName(e.target.value)}
          >
            <option value="">All</option>
            {uniqueTemplateNames.map((templateName, index) => (
              <option key={index} value={templateName}>
                {templateName}
              </option>
            ))}
          </select>

          <button
            className="ml-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            onClick={() => router.push("/pages/job-template")}
          >
            Create New Template
          </button>
        </div>
              

        </div>
        <TableComponent
          headers={jobItemTemplateHeader}
          datas={jobItemTemplateBody}
          TableName="Checklist Templates"
          filterColumn="LINE NAME"
          searchColumn="Checklist Template Name"
          currentPage={currentPage}
          onPageChange={(page) => setCurrentPage(page)}
        />
      </div>
    </Layout>
  );
};

export default Page;
